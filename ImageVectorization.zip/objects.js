class Poblacion {

    constructor(size) {
        this.generaciones = [];    // array de generaciones

        for (let i = 0; i < size; i += 1) {
            this.generaciones.push(new Individuo(target));
        }
    }

    // Other methods and properties
}

class Generacion {

    constructor(size, target) {
        this.individuos = [];
        this.size = size || 1;
        this.mostFit = [];
        
        this.number = poblacion.generaciones.length() // revisar

        //for (let i = 0; i < size; i += 1) {
        //    this.individuos.push(new Individuo(target));
        //}
    }

    // Other methods and properties
}

class Individuo {

    constructor(target, width, height) {
        this.target = target;
        this.match = 0;
        this.value = {

        }
    }

    fitness(){

    }
}

//export { Poblacion, Generacion, Individuo };